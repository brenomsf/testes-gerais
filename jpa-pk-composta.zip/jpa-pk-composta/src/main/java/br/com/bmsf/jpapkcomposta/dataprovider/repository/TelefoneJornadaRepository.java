package br.com.bmsf.jpapkcomposta.dataprovider.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.bmsf.jpapkcomposta.dataprovider.entity.TelefoneEntity;
import br.com.bmsf.jpapkcomposta.dataprovider.entity.TelefoneJornadaEntity;
import br.com.bmsf.jpapkcomposta.dataprovider.entity.TelefoneJornadaId;

@Repository
public interface TelefoneJornadaRepository extends JpaRepository<TelefoneJornadaEntity, TelefoneJornadaId>{

}
