package br.com.bmsf.jpapkcomposta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaPkCompostaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaPkCompostaApplication.class, args);
	}

}
