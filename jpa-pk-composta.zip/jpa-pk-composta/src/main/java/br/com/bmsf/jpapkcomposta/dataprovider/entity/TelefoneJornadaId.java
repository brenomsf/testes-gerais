package br.com.bmsf.jpapkcomposta.dataprovider.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class TelefoneJornadaId implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "id_telefone")
	public int idTelefone;
	
	@Column(name = "id_participante")
	public int idParticipante;
	
	@Column(name = "id_jornada")
	public int idJornada;
}
