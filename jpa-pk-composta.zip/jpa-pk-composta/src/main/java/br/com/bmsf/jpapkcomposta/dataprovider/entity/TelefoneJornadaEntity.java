package br.com.bmsf.jpapkcomposta.dataprovider.entity;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Telefone_Jornada")
public class TelefoneJornadaEntity {
	
	@EmbeddedId
	public TelefoneJornadaId id;
	
	@ManyToOne
//	@JoinColumn(name = "id_telefone")
	public TelefoneEntity telefone;
	
	@ManyToOne
//	@JoinColumn(name = "id_participante")
	public ParticipanteEntity participante;
	
	@ManyToOne
//	@JoinColumn(name = "id_jornada")
	public JornadaEntity jornada;
}
