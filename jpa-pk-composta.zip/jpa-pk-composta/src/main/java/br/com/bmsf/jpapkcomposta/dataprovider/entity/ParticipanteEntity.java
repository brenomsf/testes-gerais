package br.com.bmsf.jpapkcomposta.dataprovider.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Participante")
public class ParticipanteEntity {
	
	@Id
	@Column(name = "idParticipante")
	public int idParticipante;
	
	@OneToMany
	public List<TelefoneEntity> telefones;
	
	public String nome;

}
