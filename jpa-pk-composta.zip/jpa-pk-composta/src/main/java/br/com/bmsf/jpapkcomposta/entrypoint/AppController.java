package br.com.bmsf.jpapkcomposta.entrypoint;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.bmsf.jpapkcomposta.dataprovider.entity.TelefoneEntity;
import br.com.bmsf.jpapkcomposta.dataprovider.entity.TelefoneJornadaEntity;
import br.com.bmsf.jpapkcomposta.dataprovider.entity.TelefoneJornadaId;
import br.com.bmsf.jpapkcomposta.dataprovider.repository.JornadaRepository;
import br.com.bmsf.jpapkcomposta.dataprovider.repository.ParticipanteRepository;
import br.com.bmsf.jpapkcomposta.dataprovider.repository.TelefoneJornadaRepository;
import br.com.bmsf.jpapkcomposta.dataprovider.repository.TelefoneRepository;

@Controller
@RequestMapping
public class AppController {

	@Autowired
	private ParticipanteRepository participanteRepository;
	
	@Autowired
	private TelefoneRepository telefoneRepository;
	
	@Autowired
	private JornadaRepository jornadaRepository;
	
	@Autowired
	private TelefoneJornadaRepository telJornadaRepository;
	
	@GetMapping
	public String buscarTelefone() {
		
		return telefoneRepository.findAll().toString();
	}
	
	@PostMapping
	public String salvarTelefone() {
		
		TelefoneEntity telEntity = new TelefoneEntity();
		telEntity.idTelefone = 1;
		telEntity.numero = "989345678";
		
		TelefoneJornadaEntity jorEntity  = new TelefoneJornadaEntity();
		TelefoneJornadaId telJorId = new TelefoneJornadaId();
		
		telJorId.idJornada = 1;
		telJorId.idParticipante = 1;
		telJorId.idTelefone = telEntity.idTelefone;
		
		jorEntity.id = telJorId;
		jorEntity.telefone = telEntity;
		jorEntity.participante = participanteRepository.findById(1).get();
		jorEntity.jornada = jornadaRepository.findById(1).get();
		
		telEntity.participante = participanteRepository.findById(1).get();
		telEntity.jornadas = Collections.emptyList();
//		telEntity.jornadas.add(jorEntity);
		
		telefoneRepository.save(telEntity);
		
		telJornadaRepository.save(jorEntity);
		
		return "SUCESSO";
	}
	
}
