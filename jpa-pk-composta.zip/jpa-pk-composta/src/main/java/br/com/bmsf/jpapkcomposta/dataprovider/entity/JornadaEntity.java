package br.com.bmsf.jpapkcomposta.dataprovider.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Jornada")
public class JornadaEntity {
	
	@Id
	public int idJornada;
	
	@OneToMany
	public List<TelefoneJornadaEntity> telefones;
	
	public String nome;

}
