package br.com.bmsf.jpapkcomposta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaPkCompostaApplicationTests {

	@Test
	void contextLoads() {
	}

}
